// config.js

// dev config
// export const API_URL = "http://localhost/PHPdev/api.pompay/api/v0.0.1/routes/";
// export const POMPAY_URL = "http://localhost/PHPdev/POMPAY/agency/p2/";

// prod config
export const API_URL = "https://pompay.co.zw/apis/pompay/v0.0.2/routes/";
export const POMPAY_URL = "https://agency.pompay.co.zw/checkout/";
