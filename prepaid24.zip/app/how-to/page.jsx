export default function Howto(){

    return (
        <main>
            <h2>How to</h2>
        </main>
    )
}