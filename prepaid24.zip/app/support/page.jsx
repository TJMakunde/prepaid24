export default function Support(){

    return (
        <main>
            <h2>Support</h2>
        </main>
    )
}