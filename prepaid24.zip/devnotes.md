- [x] home page hero
- [x] links in home tiles
- [x] remove about us section
- [x] payment tile bg gray-400
- [~] svg standard size 600x800  
- [x] back buttons
- [ ] support copy
- [ ] how to copy
- [ ] handle customeAccountVerification failure
    - [ ] notify

- [ ] error pages


<!-- TODO -->
    [] check redirect params;
    [] add redirect to dstv checkout
